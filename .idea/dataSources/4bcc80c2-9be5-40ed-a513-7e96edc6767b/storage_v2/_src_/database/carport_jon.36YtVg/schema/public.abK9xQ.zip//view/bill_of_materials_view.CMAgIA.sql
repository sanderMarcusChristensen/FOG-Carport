create view bill_of_materials_view
            (product_id, product_variant_id, order_id, carport_width, carport_length, status, date, user_id,
             total_price, order_item_id, quantity, description, product_variant_length, product_name, unit, price)
as
SELECT product_variant.product_id,
       io.product_variant_id,
       orders.order_id,
       orders.carport_width,
       orders.carport_length,
       orders.status,
       orders.date,
       orders.user_id,
       orders.total_price,
       io.order_item_id,
       io.quantity,
       io.description,
       product_variant.product_variant_length,
       product.product_name,
       product.unit,
       product.price
FROM orders
         JOIN order_item io USING (order_id)
         JOIN product_variant USING (product_variant_id)
         JOIN product USING (product_id);

alter table bill_of_materials_view
    owner to postgres;

